<!doctype html>
<html>
<head>
<title>Change Password</title>
</head>
<body>    
<form>
  <fieldset>
    <legend>CHANGE PASSWORD</legend>
  <label>Current Password:</label>
<input type ="password" name="currentpassword" required><br><br>
<label>New Password</label>
<input type ="newpassword" name="newpassword" required><br><br>
<label>Retype New Password</label>
<input type ="retypenewpassword" name="retypenewpassword" required><br><hr>
<input type="submit" value="Change">
<a href="userhomepage.php">Home</a></a>
  </fieldset>
</form>
</body>
</html>
