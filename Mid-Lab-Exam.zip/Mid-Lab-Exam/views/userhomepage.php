<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User's Home Page</title>
</head>
<body>
  <h1>Welcome User!</h1>
  <br><br><br><br>
  <a href="profile.php">Profile</a><br>
  <a href="changepassword.php">Change Password</a><br>
  <a href="logout.php">Logout</a><br>
</body>
</html>
